import anvil.server
import anvil.users
from anvil import open_form
import custom_signup.login_flow

custom_signup.login_flow.do_email_confirm_or_reset()
open_form('Test')